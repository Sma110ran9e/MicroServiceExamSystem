package com.example.examsystem.service;

import com.example.examsystem.dto.TestQuestion;

import java.util.List;

public interface PracticeService {

    TestQuestion findOneById(Integer id);
    String findOption(Integer id);
    List<TestQuestion> findSome();
    void initpracticereport(Integer userid, Integer one, Integer two, Integer three, Integer four, Integer five,
                            Integer six, Integer seven, Integer eight, Integer nine, Integer ten, Integer grade);
    List<TestQuestion> findAllQuestionByType(Integer type);
}
