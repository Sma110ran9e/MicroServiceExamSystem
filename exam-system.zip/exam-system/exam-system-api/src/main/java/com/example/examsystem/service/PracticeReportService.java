package com.example.examsystem.service;

import  com.example.examsystem.dto.PracticeReport;

import java.util.List;

public interface PracticeReportService {
    PracticeReport findOnePracticeReportByUserId(Integer userid);
    List<PracticeReport> findAllPracticeReportByUserId(Integer id);
    Integer count1();
    Integer count2();
    Integer count3();
    Integer count4();
    Integer count5();
    Integer count6(Integer grade);
}
