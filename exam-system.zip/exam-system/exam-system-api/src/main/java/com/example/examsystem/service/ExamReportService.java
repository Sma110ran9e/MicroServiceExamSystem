package com.example.examsystem.service;

import com.example.examsystem.dto.ExamReport;

public interface ExamReportService {
    ExamReport findOneExamReportByUserId(Integer userid);
    Integer count1(String examName);
    Integer count2(String examName);
    Integer count3(String examName);
    Integer count4(String examName);
    Integer count5(String examName);
    Integer count6(Integer grade, String examName);
}
