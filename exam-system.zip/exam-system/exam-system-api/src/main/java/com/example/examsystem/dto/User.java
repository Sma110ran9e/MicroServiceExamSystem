package com.example.examsystem.dto;

import java.io.Serializable;

public class User implements Serializable {
    private Integer id;
    private String name;
    private Integer schoolId;
    private String password;
    private String major;
    private String classes;
    private Integer type;

    public User(Integer id, String name, Integer schoolId, String password, String major, String classes, Integer type) {
        this.id = id;
        this.name = name;
        this.schoolId = schoolId;
        this.password = password;
        this.major = major;
        this.classes = classes;
        this.type = type;
    }

    public User() {
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", schoolId=" + schoolId +
                ", password='" + password + '\'' +
                ", major='" + major + '\'' +
                ", classes='" + classes + '\'' +
                ", type=" + type +
                '}';
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSchoolId() {
        return schoolId;
    }

    public void setSchoolId(Integer schoolId) {
        this.schoolId = schoolId;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getClasses() {
        return classes;
    }

    public void setClasses(String classes) {
        this.classes = classes;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

}
