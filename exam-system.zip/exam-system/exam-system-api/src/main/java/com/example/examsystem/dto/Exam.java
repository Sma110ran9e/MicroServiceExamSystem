package com.example.examsystem.dto;

import java.io.Serializable;
import java.util.Date;

public class Exam implements Serializable {
    private Integer id;
    private Integer userId;
    private String userName;
    private String examName;
    private Integer examType;
    private Date time;
    private Integer oneId;
    private Integer twoId;
    private Integer threeId;
    private Integer fourId;
    private Integer fiveId;
    private Integer sixId;
    private Integer sevenId;
    private Integer eightId;
    private Integer nineId;
    private Integer tenId;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getExamName() {
        return examName;
    }

    public void setExamName(String examName) {
        this.examName = examName;
    }

    public Integer getExamType() {
        return examType;
    }

    public void setExamType(Integer examType) {
        this.examType = examType;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public Integer getOneId() {
        return oneId;
    }

    public void setOneId(Integer oneId) {
        this.oneId = oneId;
    }

    public Integer getTwoId() {
        return twoId;
    }

    public void setTwoId(Integer twoId) {
        this.twoId = twoId;
    }

    public Integer getThreeId() {
        return threeId;
    }

    public void setThreeId(Integer threeId) {
        this.threeId = threeId;
    }

    public Integer getFourId() {
        return fourId;
    }

    public void setFourId(Integer fourId) {
        this.fourId = fourId;
    }

    public Integer getFiveId() {
        return fiveId;
    }

    public void setFiveId(Integer fiveId) {
        this.fiveId = fiveId;
    }

    public Integer getSixId() {
        return sixId;
    }

    public void setSixId(Integer sixId) {
        this.sixId = sixId;
    }

    public Integer getSevenId() {
        return sevenId;
    }

    public void setSevenId(Integer sevenId) {
        this.sevenId = sevenId;
    }

    public Integer getEightId() {
        return eightId;
    }

    public void setEightId(Integer eightId) {
        this.eightId = eightId;
    }

    public Integer getNineId() {
        return nineId;
    }

    public void setNineId(Integer nineId) {
        this.nineId = nineId;
    }

    public Integer getTenId() {
        return tenId;
    }

    public void setTenId(Integer tenId) {
        this.tenId = tenId;
    }

}
