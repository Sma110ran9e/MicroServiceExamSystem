package com.example.examsystem.service;

import com.example.examsystem.dto.User;

import java.util.List;

public interface UserService {
    User findUserBySchoolIdAndPwd(Integer schoolId, String password);
    List<User> findAll();
    void insertUser(String name, Integer schoolId, String major, String classes, String password);
    void deleteUser(Integer id);
    User findOneById(Integer id);
    void updateUser(String name, Integer schoolId, String major, String classes, String password, Integer id);

}
