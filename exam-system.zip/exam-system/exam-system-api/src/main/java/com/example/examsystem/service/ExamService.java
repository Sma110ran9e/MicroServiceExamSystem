package com.example.examsystem.service;

import com.example.examsystem.dto.Exam;
import com.example.examsystem.dto.TestQuestion;

import java.util.Date;
import java.util.List;

public interface ExamService {
    List<Exam> findAllExam();
    void insertexam(Integer userId, String userName, String examName, Integer examType, Date time,Integer oneId, Integer twoId, Integer threeId, Integer fourId, Integer fiveId
            , Integer sixId, Integer sevenId, Integer eightId, Integer nineId, Integer tenId);
    Exam findOneExamById(Integer id);
    void initexamreport(Integer userId, String examName,Integer one, Integer two, Integer three, Integer four, Integer five,
                        Integer six, Integer seven, Integer eight, Integer nine, Integer ten, Integer grade);
    List<TestQuestion> findAllQuestionByType(Integer type);



}
