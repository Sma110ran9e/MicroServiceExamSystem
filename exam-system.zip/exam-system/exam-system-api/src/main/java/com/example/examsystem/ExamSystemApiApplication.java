package com.example.examsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamSystemApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExamSystemApiApplication.class, args);
    }

}
