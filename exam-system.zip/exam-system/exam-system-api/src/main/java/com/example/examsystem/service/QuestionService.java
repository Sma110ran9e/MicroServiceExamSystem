package com.example.examsystem.service;

import com.example.examsystem.dto.TestQuestion;

import java.util.List;

public interface QuestionService {
    List<TestQuestion> findAll();
    void insertQuestion(String qDescrip, String optionA, String optionB, String optionC, String optionD, Integer answer, Integer type);
    void deleteQuestion(Integer id);

    void updateQuestion(String qDescrip, String optionA, String optionB, String optionC, String optionD, Integer answer, String type, Integer id);

  //练习
    TestQuestion findOneById(Integer id);
    String findOption(Integer id);
//    List<TestQuestion> findSome();
//    void initpracticereport(Integer userid,Integer one,Integer two,Integer three,Integer four,Integer five,
//                        Integer six,Integer seven,Integer eight,Integer nine,Integer ten,Integer grade);
//    List<TestQuestion> findAllQuestionByType(Integer type);
}
