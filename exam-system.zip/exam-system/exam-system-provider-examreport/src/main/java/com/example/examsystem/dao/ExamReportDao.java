package com.example.examsystem.dao;



import com.example.examsystem.dto.ExamReport;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Repository
@Mapper
public interface ExamReportDao {
    @Select("select * from examreport where userid=#{userid} order by id desc limit 0,1")
    ExamReport findOneExamReportByUserId(Integer userid);

    @Select("select count(*) from examreport where grade>=0 and grade<20 and examName=#{examName}")
    Integer count1(String examName);
    @Select("select count(*) from examreport where grade>=20 and grade<40 and examName=#{examName}")
    Integer count2(String examName);
    @Select("select count(*) from examreport where grade>=40 and grade<60 and examName=#{examName}")
    Integer count3(String examName);
    @Select("select count(*) from examreport where grade>=60 and grade<80 and examName=#{examName}")
    Integer count4(String examName);
    @Select("select count(*) from examreport where grade>=80 and grade<=100 and examName=#{examName}")
    Integer count5(String examName);
    @Select("select count(*) from examreport where grade<#{grade} and examName=#{examName}")
    Integer count6(Integer grade, String examName);
}
