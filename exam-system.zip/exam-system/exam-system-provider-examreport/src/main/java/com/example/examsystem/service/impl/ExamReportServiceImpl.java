package com.example.examsystem.service.impl;


import com.example.examsystem.dao.ExamReportDao;
import com.example.examsystem.dto.ExamReport;

import com.example.examsystem.service.ExamReportService;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service(version = "${ExamReport.service.version}",application = "${dubbo.application.id}")
public class ExamReportServiceImpl implements ExamReportService {
    @Autowired
    ExamReportDao examReportDao;
    public ExamReport findOneExamReportByUserId(Integer userid){
        return examReportDao.findOneExamReportByUserId(userid);
    }
    public Integer count1(String examName){
        return examReportDao.count1(examName);
    }
    public Integer count2(String examName){
        return examReportDao.count2(examName);
    }
    public Integer count3(String examName){
        return examReportDao.count3(examName);
    }
    public Integer count4(String examName){
        return examReportDao.count4(examName);
    }
    public Integer count5(String examName){
        return examReportDao.count5(examName);
    }
    public Integer count6(Integer grade,String examName){
        return examReportDao.count6(grade,examName);
    }
}
