package com.example.examsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamSystemProviderPracticereportApplicationTests {

    @Test
    void contextLoads() {
    }

}
