package com.example.examsystem.dao;

import com.example.examsystem.dto.PracticeReport;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface PracticeReportDao {
    @Select("select * from practicereport where userid=#{userid} order by id desc limit 0,1")
     PracticeReport findOnePracticeReportByUserId(Integer userid);

    @Select("select * from practicereport where userid=#{userid}")
    List<PracticeReport> findAllPracticeReportByUserId(Integer id);
    @Select("select count(*) from practicereport where grade>=0 and grade<20")
    Integer count1();
    @Select("select count(*) from practicereport where grade>=20 and grade<40")
    Integer count2();
    @Select("select count(*) from practicereport where grade>=40 and grade<60")
    Integer count3();
    @Select("select count(*) from practicereport where grade>=60 and grade<80")
    Integer count4();
    @Select("select count(*) from practicereport where grade>=80 and grade<=100")
    Integer count5();
    @Select("select count(*) from practicereport where grade<#{grade}")
    Integer count6(Integer grade);
}
