package com.example.examsystem.service.impl;

import com.example.examsystem.dao.PracticeReportDao;
import com.example.examsystem.dto.PracticeReport;
import com.example.examsystem.service.PracticeReportService;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service(version = "${PracticeReport.service.version}",application = "${dubbo.application.id}")
public class PracticeReportServiceImpl implements PracticeReportService {
    @Autowired
    PracticeReportDao practiceReportDao;
    public PracticeReport findOnePracticeReportByUserId(Integer userid){
        return practiceReportDao.findOnePracticeReportByUserId(userid);
    }
    public List<PracticeReport> findAllPracticeReportByUserId(Integer id){
        return practiceReportDao.findAllPracticeReportByUserId(id);
    }
    public Integer count1(){
        return practiceReportDao.count1();
    }
    public Integer count2(){
        return practiceReportDao.count2();
    }
    public Integer count3(){
        return practiceReportDao.count3();
    }
    public Integer count4(){
        return practiceReportDao.count4();
    }
    public Integer count5(){
        return practiceReportDao.count5();
    }
    public Integer count6(Integer grade){
        return practiceReportDao.count6(grade);
    }
}
