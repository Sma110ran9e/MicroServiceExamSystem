package com.example.examsystem.service.impl;

import com.example.examsystem.dao.UserDao;
import com.example.examsystem.dto.User;
import com.example.examsystem.service.UserService;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;

@Service(version = "${role.service.version}",application = "${dubbo.application.id}")
public class UserServiceImpl implements UserService {
    @Autowired
    UserDao userDao;

    public User findUserBySchoolIdAndPwd(Integer schoolId, String password) {
        return userDao.findUserBySchoolIdAndPwd(schoolId, password);
    }

    public List<User> findAll(){
        return userDao.findAll();
    }
    public  void insertUser(String name,Integer schoolId, String major, String classes,String password){
         userDao.insertUser(name,schoolId,major,classes,password);
    }
    public void deleteUser(Integer id){
        userDao.deleteUser(id);
    }
    public  User findOneById(Integer id){
        return userDao.findOneById(id);
    }
    public void updateUser(String name,Integer schoolId,String major,String classes,String password,Integer id){
        userDao.updateUser(name,schoolId,major,classes,password,id);
    }
}
