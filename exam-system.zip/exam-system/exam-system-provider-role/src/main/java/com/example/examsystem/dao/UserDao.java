package com.example.examsystem.dao;


import com.example.examsystem.dto.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface UserDao {
    @Select("select * from user where schoolId=#{schoolId} and password=#{password}")
    User findUserBySchoolIdAndPwd(@Param("schoolId") Integer schoolId, @Param("password") String password);
    @Select("select * from user")
    List<User> findAll();
    @Insert("insert into user (name,schoolId,major,type,classes,password) values(#{name},#{schoolId},#{major},2,#{classes},#{password})")
    void insertUser(@Param("name") String name, @Param("schoolId") Integer schoolId, @Param("major") String major, @Param("classes") String classes, @Param("password") String password);
    @Delete("delete from user where id=#{id}")
    void deleteUser(@Param("id") Integer id);
    @Select("select * from user where id=#{id}")
    User findOneById(@Param("id") Integer id);
    @Update("update user set name=#{name},schoolId=#{schoolId},major=#{major},classes=#{classes},password=#{password} where id=#{id}")
    void updateUser(@Param("name") String name, @Param("schoolId") Integer schoolId, @Param("major") String major, @Param("classes") String classes, @Param("password") String password, @Param("id") Integer id);

}