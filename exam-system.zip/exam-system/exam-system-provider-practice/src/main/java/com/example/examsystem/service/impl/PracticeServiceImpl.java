package com.example.examsystem.service.impl;

import com.example.examsystem.dao.PracticeDao;
import com.example.examsystem.dto.TestQuestion;

import com.example.examsystem.service.PracticeService;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service(version = "${practice.service.version}",application = "${dubbo.application.id}")
public class PracticeServiceImpl implements PracticeService {
    @Autowired
    PracticeDao practiceDao;
    public TestQuestion findOneById(Integer id) {
        return practiceDao.findOneById(id);
    }
    //练习
    public String findOption(Integer id) {
        String rightoption;
        TestQuestion testQuestion = practiceDao.findOneById(id);
        if (testQuestion.getAnswer() == 1) {
            rightoption = testQuestion.getOptionA();
        } else if (testQuestion.getAnswer() == 2) {
            rightoption = testQuestion.getOptionB();
        } else if (testQuestion.getAnswer() == 3) {
            rightoption = testQuestion.getOptionC();
        } else rightoption = testQuestion.getOptionD();
        return rightoption;
    }
    public List<TestQuestion> findSome(){
        return practiceDao.findSome();
    }

    public  void initpracticereport(Integer userid,Integer one,Integer two,Integer three,Integer four,Integer five,
                                    Integer six,Integer seven,Integer eight,Integer nine,Integer ten,Integer grade){
        practiceDao.initpracticereport(userid,one,two,three,four,five,six,seven,eight,nine,ten,grade);
    }
    public  List<TestQuestion> findAllQuestionByType(Integer type){
        return  practiceDao.findAllQuestionByType(type);
    }
}
