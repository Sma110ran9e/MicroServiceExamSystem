package com.example.examsystem.dao;

import com.example.examsystem.dto.TestQuestion;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface PracticeDao {

    @Select("select * from testquestion order by rand() limit 10")   //从数据库随机取出10道题
    List<TestQuestion> findSome();
    @Insert("insert into practicereport(userid,one,two,three,four,five,six,seven,eight,nine,ten,grade) " +
            "values(#{userid},#{one},#{two},#{three},#{four},#{five},#{six},#{seven},#{eight},#{nine},#{ten},#{grade})")
    void initpracticereport(Integer userid, Integer one, Integer two, Integer three, Integer four, Integer five,
                            Integer six, Integer seven, Integer eight, Integer nine, Integer ten, Integer grade);
    @Select("select * from testquestion where type=#{type}")
    List<TestQuestion> findAllQuestionByType(@Param("type") Integer type);
    @Select("select * from testquestion where id=#{id}")
    TestQuestion findOneById(@Param("id") Integer id);
}
