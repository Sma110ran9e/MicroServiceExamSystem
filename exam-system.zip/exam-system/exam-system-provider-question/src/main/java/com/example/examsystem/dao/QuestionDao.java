package com.example.examsystem.dao;

import com.example.examsystem.dto.TestQuestion;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@Mapper
public interface QuestionDao {
    @Select("select * from testquestion")
    List<TestQuestion> findAll();
    @Insert("insert into testquestion(qDescrip,optionA,optionB,optionC,optionD,answer,type) " +
            "values(#{qDescrip},#{optionA},#{optionB},#{optionC},#{optionD},#{answer},#{type})")
    void insertQuestion(@Param("qDescrip") String qDescrip, @Param("optionA") String optionA, @Param("optionB") String optionB, @Param("optionC") String optionC, @Param("optionD") String optionD, @Param("answer") Integer answer, @Param("type") Integer type);
    @Delete("delete from testquestion where id=#{id}")
    void deleteQuestion(@Param("id") Integer id);
    @Select("select * from testquestion where id=#{id}")
    TestQuestion findOneById(@Param("id") Integer id);
    @Update("update testquestion set qDescrip=#{qDescrip},optionA=#{optionA},optionB=#{optionB},optionC=#{optionC},optionD=#{optionD},answer=#{answer},type=#{type} where id=#{id}")
    void updateQuestion(@Param("qDescrip") String qDescrip, @Param("optionA") String optionA, @Param("optionB") String optionB, @Param("optionC") String optionC, @Param("optionD") String optionD, @Param("answer") Integer answer, @Param("type") String type, @Param("id") Integer id);


//
//    @Select("select * from testquestion order by rand() limit 10")   //从数据库随机取出10道题
//    List<TestQuestion> findSome();
//    @Insert("insert into practicereport(userid,one,two,three,four,five,six,seven,eight,nine,ten,grade) " +
//            "values(#{userid},#{one},#{two},#{three},#{four},#{five},#{six},#{seven},#{eight},#{nine},#{ten},#{grade})")
//    void initpracticereport(Integer userid,Integer one,Integer two,Integer three,Integer four,Integer five,
//                        Integer six,Integer seven,Integer eight,Integer nine,Integer ten,Integer grade);
//    @Select("select * from testquestion where type=#{type}")
//    List<TestQuestion> findAllQuestionByType(@Param("type") Integer type);

}
