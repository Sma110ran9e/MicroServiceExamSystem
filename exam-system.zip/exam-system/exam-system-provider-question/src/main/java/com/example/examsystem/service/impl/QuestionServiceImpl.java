package com.example.examsystem.service.impl;

import com.example.examsystem.dao.QuestionDao;
import com.example.examsystem.dto.TestQuestion;
import com.example.examsystem.service.QuestionService;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service(version = "${question.service.version}",application = "${dubbo.application.id}")
public class QuestionServiceImpl implements QuestionService {
    @Autowired
    QuestionDao questionDao;

    public List<TestQuestion> findAll() {
        return questionDao.findAll();
    }

    public void insertQuestion(String qDescrip, String optionA, String optionB, String optionC, String optionD, Integer answer, Integer type) {
        questionDao.insertQuestion(qDescrip, optionA, optionB, optionC, optionD, answer, type);
    }

    public void deleteQuestion(Integer id) {
        questionDao.deleteQuestion(id);
    }

    public TestQuestion findOneById(Integer id) {
        return questionDao.findOneById(id);
    }

    public void updateQuestion(String qDescrip, String optionA, String optionB, String optionC, String optionD, Integer answer, String type, Integer id) {
        questionDao.updateQuestion(qDescrip, optionA, optionB, optionC, optionD, answer, type, id);
    }
//练习
    public String findOption(Integer id) {
        String rightoption;
        TestQuestion testQuestion = questionDao.findOneById(id);
        if (testQuestion.getAnswer() == 1) {
            rightoption = testQuestion.getOptionA();
        } else if (testQuestion.getAnswer() == 2) {
            rightoption = testQuestion.getOptionB();
        } else if (testQuestion.getAnswer() == 3) {
            rightoption = testQuestion.getOptionC();
        } else rightoption = testQuestion.getOptionD();
        return rightoption;
    }
//    public List<TestQuestion> findSome(){
//        return questionDao.findSome();
//    }
//
//    public  void initpracticereport(Integer userid,Integer one,Integer two,Integer three,Integer four,Integer five,
//                                Integer six,Integer seven,Integer eight,Integer nine,Integer ten,Integer grade){
//        questionDao.initpracticereport(userid,one,two,three,four,five,six,seven,eight,nine,ten,grade);
//    }
//    public  List<TestQuestion> findAllQuestionByType(Integer type){
//        return  questionDao.findAllQuestionByType(type);
//    }
}

