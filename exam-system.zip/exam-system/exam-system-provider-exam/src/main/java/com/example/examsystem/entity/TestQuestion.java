package com.example.examsystem.entity;

import java.io.Serializable;

public class TestQuestion implements Serializable {
    private Integer id;
    private String qDescrip;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private Integer answer;
    private Integer type;

    public TestQuestion(Integer id, String qDescrip, String optionA, String optionB, String optionC, String optionD, Integer answer, Integer type) {
        this.id = id;
        this.qDescrip = qDescrip;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.answer = answer;
        this.type = type;
    }

    public TestQuestion() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getqDescrip() {
        return qDescrip;
    }

    public void setqDescrip(String qDescrip) {
        this.qDescrip = qDescrip;
    }

    public String getOptionA() {
        return optionA;
    }

    public void setOptionA(String optionA) {
        this.optionA = optionA;
    }

    public String getOptionB() {
        return optionB;
    }

    public void setOptionB(String optionB) {
        this.optionB = optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public void setOptionC(String optionC) {
        this.optionC = optionC;
    }

    public String getOptionD() {
        return optionD;
    }

    public void setOptionD(String optionD) {
        this.optionD = optionD;
    }

    public Integer getAnswer() {
        return answer;
    }

    public void setAnswer(Integer answer) {
        this.answer = answer;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "testquestion{" +
                "id=" + id +
                ", qDescrip='" + qDescrip + '\'' +
                ", optionA='" + optionA + '\'' +
                ", optionB='" + optionB + '\'' +
                ", optionC='" + optionC + '\'' +
                ", optionD='" + optionD + '\'' +
                ", answer=" + answer +
                ", type=" + type +
                '}';
    }
}
