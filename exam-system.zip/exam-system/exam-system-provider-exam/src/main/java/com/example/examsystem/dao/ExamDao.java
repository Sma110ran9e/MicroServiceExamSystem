package com.example.examsystem.dao;

import com.example.examsystem.dto.Exam;
import com.example.examsystem.dto.TestQuestion;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
@Mapper
public interface ExamDao {
    @Select("select * from exam ")
    List<Exam> findAllExam();
    @Insert("insert into exam (userId,userName,examName,examType,time,oneId,twoId,threeId,fourId,fiveId,sixId,sevenId,eightId,nineId,tenId)" +
            "values(#{userId},#{userName},#{examName},#{examType},#{time},#{oneId},#{twoId},#{threeId},#{fourId},#{fiveId},#{sixId},#{sevenId},#{eightId},#{nineId},#{tenId})")
    void insertexam(Integer userId, String userName, String examName, Integer examType, Date time,Integer oneId, Integer twoId, Integer threeId, Integer fourId, Integer fiveId
            , Integer sixId, Integer sevenId, Integer eightId, Integer nineId, Integer tenId);
    @Select("select * from exam where id=#{id}")
    Exam findOneExamById(Integer id);
    @Insert("insert into examreport (userId,examName,one,two,three,four,five,six,seven,eight,nine,ten,grade)" +
            " values(#{userId},#{examName},#{one},#{two},#{three},#{four},#{five},#{six},#{seven},#{eight},#{nine},#{ten},#{grade})")
    void initexamreport(Integer userId, String examName, Integer one, Integer two, Integer three, Integer four, Integer five,
                        Integer six, Integer seven, Integer eight, Integer nine, Integer ten, Integer grade);
    @Select("select * from testquestion where type=#{type}")
    List<TestQuestion> findAllQuestionByType(@Param("type") Integer type);
}
