package com.example.examsystem.service.impl;


import com.example.examsystem.dao.ExamDao;
import com.example.examsystem.dto.Exam;
import com.example.examsystem.dto.TestQuestion;

import com.example.examsystem.service.ExamService;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;


import java.util.Date;
import java.util.List;

@Service(version = "${exam.service.version}",application = "${dubbo.application.id}")
public class ExamServiceImpl implements ExamService {
    @Autowired
    ExamDao examDao;
    public List<Exam> findAllExam(){
        return examDao.findAllExam();
    }
    public void insertexam(Integer userId, String userName, String examName, Integer examType, Date time,Integer oneId, Integer twoId, Integer threeId, Integer fourId, Integer fiveId
            , Integer sixId, Integer sevenId, Integer eightId, Integer nineId, Integer tenId){
        examDao.insertexam(userId,userName,examName,examType,time,oneId,twoId,threeId,fourId,fiveId,sixId,sevenId,eightId,nineId,tenId);
    }
    public Exam findOneExamById(Integer id){
        return examDao.findOneExamById(id);
    }
    public void initexamreport(Integer userId,String examName,Integer one,Integer two,Integer three, Integer four,Integer five,
                               Integer six,Integer seven,Integer eight,Integer nine,Integer ten,Integer grade){
        examDao.initexamreport(userId,examName,one,two,three,four,five,six,seven,eight,nine,ten,grade);
    }
      public  List<TestQuestion> findAllQuestionByType(Integer type){
        return  examDao.findAllQuestionByType(type);
    }
}
