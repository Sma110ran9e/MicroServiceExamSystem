package com.example.examsystem.controller;


import com.example.examsystem.dto.Exam;
import com.example.examsystem.dto.ExamReport;
import com.example.examsystem.dto.TestQuestion;
import com.example.examsystem.dto.User;

import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;

import com.example.examsystem.service.ExamReportService;
import com.example.examsystem.service.ExamService;
import com.example.examsystem.service.QuestionService;
import org.apache.dubbo.config.annotation.Reference;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("userexam")
public class ExamController {
    @Reference(version = "1.0.0")
    ExamService examService;
    @Reference(version = "1.0.0")
    QuestionService questionService;
    @Reference(version = "1.0.0")
    ExamReportService examReportService;
    @RequestMapping("findallexam")
    public String enterexam(HttpSession session) {
      List<Exam> examList=examService.findAllExam();
        session.setAttribute("examList",examList);
        return "examlist";
    }

    @RequestMapping("add")
    public String add(){
        return "addexam";
    }

    @RequestMapping("addexam")
    public String addexam(String examName, String examType, HttpSession session){
        Integer examType1=Integer.valueOf(examType);
        List<TestQuestion>list=examService.findAllQuestionByType(examType1);
        session.setAttribute("oneTypeList",list);
        session.setAttribute("examType1",examType1);
        session.setAttribute("examname",examName);
        return "addexam2";
    }
    @RequestMapping("addexam2")
    public ModelAndView addexam2(@RequestParam("timu") String [] id, HttpSession session){
        Integer[] Id=new Integer[11];
        for(int i=0;i<id.length;i++){
            Id[i]=Integer.valueOf(id[i]);
        }
        String examName=(String)session.getAttribute("examname");
        Integer examType=(Integer) session.getAttribute("examType1");
        User user=(User)session.getAttribute("user2");
        Date date = new Date();// 新建此时的的系统时间
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, +5);//
        Date examTime = calendar.getTime();
        examService.insertexam(user.getId(),user.getName(),examName,examType,examTime,Id[0],Id[1],Id[2],Id[3],Id[4],Id[5],Id[6],Id[7],Id[8],Id[9]);
        ModelAndView mv=new ModelAndView("redirect:findallexam");
        return mv;
    }

    @RequestMapping("studentfindallexam")
    public String studentfindAllexam(HttpSession session){
        List<Exam> examList=examService.findAllExam();
        session.setAttribute("stuexamList",examList);
        return "stuexamlist";
    }

    @RequestMapping("enterexam/{id}")
    public String stuenterexam(@PathVariable Integer id, HttpSession session){
        List<Exam> examList=examService.findAllExam();
        Date date=examList.get(id-1).getTime();
        Date date1=new Date();
        if(date.getTime() < date1.getTime()) {
            return "examtimeerror";
        }
        Exam exam=examService.findOneExamById(id);
        session.setAttribute("examId",id);
        List<TestQuestion> testQuestions=new ArrayList<TestQuestion>();
        TestQuestion testQuestion1=questionService.findOneById(exam.getOneId());
        testQuestions.add(testQuestion1);
        TestQuestion testQuestion2=questionService.findOneById(exam.getTwoId());
        testQuestions.add(testQuestion2);
        TestQuestion testQuestion3=questionService.findOneById(exam.getThreeId());
        testQuestions.add(testQuestion3);
        TestQuestion testQuestion4=questionService.findOneById(exam.getFourId());
        testQuestions.add(testQuestion4);
        TestQuestion testQuestion5=questionService.findOneById(exam.getFiveId());
        testQuestions.add(testQuestion5);
        TestQuestion testQuestion6=questionService.findOneById(exam.getSixId());
        testQuestions.add(testQuestion6);
        TestQuestion testQuestion7=questionService.findOneById(exam.getSevenId());
        testQuestions.add(testQuestion7);
        TestQuestion testQuestion8=questionService.findOneById(exam.getEightId());
        testQuestions.add(testQuestion8);
        TestQuestion testQuestion9=questionService.findOneById(exam.getNineId());
        testQuestions.add(testQuestion9);
        TestQuestion testQuestion10=questionService.findOneById(exam.getTenId());
        testQuestions.add(testQuestion10);
//        for(TestQuestion lists:testQuestions){
//            System.out.println(lists);
//        }
        session.setAttribute("stutestQuestions",testQuestions);
        return "examindex";
    }
    @RequestMapping(value = "checkexam")
    @ResponseBody
    public void checkexam(String option1, String option2, String option3, String option4,
                          String option5, String option6, String option7, String option8,
                          String option9, String option10, HttpSession session){
        User user=(User)session.getAttribute("user0");
        Integer examId=(Integer)session.getAttribute("examId");
        String examName=examService.findOneExamById(examId).getExamName();      //得到当前考试名称
        Integer total=0;
        String str2[]=new String[100];                             //正确答案的数组
        Integer result[]=new Integer[100];                         //存放对错的数组
        str2[0]=option1;str2[1]=option2;str2[2]=option3;str2[3]=option4;str2[4]=option5;
        str2[5]=option6;str2[6]=option7;str2[7]=option8;str2[8]=option9;str2[9]=option10;
        List<TestQuestion> testQuestions=(List<TestQuestion>)session.getAttribute("stutestQuestions");
        for(int i=0;i<testQuestions.size();i++){
            System.out.println("用户上传的答案是："+str2[i]);
            Integer id=testQuestions.get(i).getId();                //得到这些题目的ID
            String str=questionService.findOption(id);             //根据ID查询题目的答案
            System.out.println("正确答案是："+str);
            if(str.equals(str2[i])) {
                total+=10;                                          //如果答案和前端用户提交的答案一致，则此题回答正确，总分+10
                result[i]=1;
            }
            else result[i]=0;
        }
        examService.initexamreport(user.getId(),examName,result[0],result[1],result[2],result[3],result[4],result[5],result[6],result[7],result[8],result[9],total);
    }

    //ADD

    @RequestMapping("findexamreport")
    @ResponseBody
    public ModelAndView findexamreport(HttpSession session) {
        User user = (User) session.getAttribute("user0");
        Integer id=(Integer)session.getAttribute("examId");
        String examName=examService.findOneExamById(id).getExamName();
        System.out.println("考试名称为:"+examName);
        //显示该学生的本次考试成绩
        Integer grade = examReportService.findOneExamReportByUserId(user.getId()).getGrade();
        //将每题对错画成条形统计图
        ExamReport examReport = examReportService.findOneExamReportByUserId(user.getId());
        //统计该门考试不同分数区间的人数，画成饼图
        Integer count1 = examReportService.count1(examName);      //0-20
        Integer count2 = examReportService.count2(examName);      //20-40
        Integer count3 = examReportService.count3(examName);      //40-60
        Integer count4 = examReportService.count4(examName);      //60-80
        Integer count5 = examReportService.count5(examName);      //80-100
        Integer count6 = examReportService.count6(grade, examName); //统计比该生分数低的记录
        //显示该学生该考试超越了百分之？%的学生
        Double rank = count6 * 1.0 / ((count1 + count2 + count3 + count4 + count5) * 1.0);
        System.out.println("本次考试成绩超越了" + rank + "的学生");
        ModelAndView mv = new ModelAndView("examresult");

        mv.addObject("examReport", examReport);
        mv.addObject("grade2", grade);
        mv.addObject("count11", count1);
        mv.addObject("count22", count2);
        mv.addObject("count33", count3);
        mv.addObject("count44", count4);
        mv.addObject("count55", count5);
        mv.addObject("count66", count6);
        mv.addObject("rank2", rank);

        return mv;
    }


    @RequestMapping("examresult")
    public String examresult(){
        return "examresult";
    }
}
