package com.example.examsystem.controller;

import com.example.examsystem.dto.TestQuestion;

import com.example.examsystem.service.QuestionService;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpSession;
import java.util.List;


@Controller
@RequestMapping("question")
public class QuestionController {
    @Reference(version = "1.0.0")
    QuestionService questionService;

    @RequestMapping("findall")
    public String findall(HttpSession session){
    List<TestQuestion> questionList=questionService.findAll();
    session.setAttribute("questionList",questionList);
    return "questionlist";
    }

    @RequestMapping("addquestion")
    public String adduser(){
        return "addquestion";
    }

    @RequestMapping("add")
    public ModelAndView add(String qDescrip,String optionA,String optionB,String optionC,String optionD,Integer answer,Integer type){
        questionService.insertQuestion(qDescrip,optionA,optionB,optionC, optionD,answer,type);
        ModelAndView mv=new ModelAndView("redirect:findall");
        return mv;
    }

    @RequestMapping("deletequestion/{id}")
    public ModelAndView deleteQuestion(@PathVariable Integer id){
        questionService.deleteQuestion(id);
        ModelAndView mv=new ModelAndView("redirect:../findall");
        return mv;
    }

    @RequestMapping("updatequestion/{id}")
    public String updateUser(@PathVariable Integer id, HttpSession session){
        TestQuestion question1=questionService.findOneById(id);
        session.setAttribute("question1",question1);
        return "updatequestion";
    }
    @RequestMapping("update")
    public ModelAndView update(String qDescrip, String optionA, String optionB, String optionC, String optionD, Integer answer, String type, HttpSession session){
        TestQuestion testQuestion=(TestQuestion) session.getAttribute("question1");
        questionService.updateQuestion(qDescrip,optionA,optionB,optionC,optionD,answer,type,testQuestion.getId());
        ModelAndView mv=new ModelAndView("redirect:findall");
        return mv;
    }
}
