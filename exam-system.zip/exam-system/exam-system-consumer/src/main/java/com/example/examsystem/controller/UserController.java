package com.example.examsystem.controller;


import com.example.examsystem.dto.User;

import com.example.examsystem.service.UserService;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("user")
public class UserController {
    @Reference(version = "1.0.0")
    UserService userService;
    @RequestMapping("checklogin")
    public String login(@RequestParam Integer schoolId, @RequestParam String password, HttpSession session, Map<String,Object>map) {
        User user = userService.findUserBySchoolIdAndPwd(schoolId, password);
        if(user!=null&&user.getType()==0){                          //管理员
            session.setAttribute("user",user);
            return "index";
        }
        else if(user!=null&&user.getType()==1){                     //教师
            session.setAttribute("user2",user);
            return "index2";
        }
        else if(user!=null&&user.getType()==2){                     //学生
            session.setAttribute("user0",user);
            return "index3";
        }
        return "login";
    }
    @RequestMapping("login")
    public String hello(){
        return "login";
    }

    @RequestMapping("findall")
    public String findAll(HttpSession session, Integer id){
        List<User>list=userService.findAll();
        session.setAttribute("userList",list);
        return "userlist";
    }

    @RequestMapping("adduser")
    public String addUser(){
        return "adduser";
    }

    @RequestMapping("add")
    public ModelAndView add(String name,Integer schoolId, String major, String classes,String password){
        userService.insertUser(name,schoolId,major,classes,password);
        ModelAndView mv=new ModelAndView("redirect:findall");
        return mv;
    }

    @RequestMapping("deleteuser/{id}")
    public ModelAndView deleteUser(@PathVariable Integer id){
        userService.deleteUser(id);
        ModelAndView mv=new ModelAndView("redirect:../findall");
        return mv;
    }

    @RequestMapping("updateuser/{id}")
    public String updateUser(@PathVariable Integer id, HttpSession session){
        User user1=userService.findOneById(id);
        session.setAttribute("user1",user1);
        return "updateuser";
    }

    @RequestMapping("update")
    public ModelAndView update(String name, Integer schoolId, String major, String classes, String password, HttpSession session){
        User user=(User)session.getAttribute("user1");
        userService.updateUser(name,schoolId,major,classes,password,user.getId());
        ModelAndView mv=new ModelAndView("redirect:findall");
        return mv;
    }
}
