package com.example.examsystem.controller;


import com.example.examsystem.dto.PracticeReport;
import com.example.examsystem.dto.TestQuestion;
import com.example.examsystem.dto.User;

import com.example.examsystem.service.ExamReportService;
import com.example.examsystem.service.PracticeReportService;
import com.example.examsystem.service.PracticeService;
import com.example.examsystem.service.QuestionService;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("userpractice")
public class PracticeController {
    @Reference(version = "1.0.0")
    QuestionService questionService;
    @Reference(version = "1.0.0")
    PracticeService practiceService;
    @Reference(version = "1.0.0")
    PracticeReportService practiceReportService;

    @RequestMapping("enterpractice")
    public String enterpractice(HttpSession session) {
        List<TestQuestion> questionList = practiceService.findSome();
        session.setAttribute("userquestionList", questionList);
        return "practiceindex";
    }

    @PostMapping("checkpractice")
    @ResponseBody
    public String checkpractice(String option1, String option2, String option3, String option4,
                                String option5, String option6, String option7, String option8,
                                String option9, String option10, HttpSession session) {
        User user=(User)session.getAttribute("user0");
        Integer total=0;
        String str2[]=new String[100];                             //正确答案的数组
        Integer result[]=new Integer[100];                         //存放对错的数组
        str2[0]=option1;str2[1]=option2;str2[2]=option3;str2[3]=option4;str2[4]=option5;
        str2[5]=option6;str2[6]=option7;str2[7]=option8;str2[8]=option9;str2[9]=option10;
        List<TestQuestion> questionList=(List<TestQuestion>)session.getAttribute("userquestionList");  //从session中读出随机的题目
        for(int i=0;i<questionList.size();i++){
            System.out.println("用户上传的答案是："+str2[i]);
            Integer id=questionList.get(i).getId();                //得到这些题目的ID
            String str=practiceService.findOption(id);             //根据ID查询题目的答案
            System.out.println("正确答案是："+str);
            if(str.equals(str2[i])) {
                total+=10;                                          //如果答案和前端用户提交的答案一致，则此题回答正确，总分+10
                result[i]=1;
            }
            else result[i]=0;
        }
        practiceService.initpracticereport(user.getId(),result[0],result[1],result[2],result[3],result[4],result[5],
                                                    result[6],result[7],result[8],result[9],total);
        System.out.println(total);
//        ModelAndView mv=new ModelAndView("redirect:examreport");
        return "提交完成，请往结果页面查看成绩！";
    }


    @RequestMapping("findpracticereport")
    @ResponseBody
    public ModelAndView findonepracticereport(HttpSession session) {
        User user = (User) session.getAttribute("user0");
        //显示该学生的本次练习成绩
        Integer grade = practiceReportService.findOnePracticeReportByUserId(user.getId()).getGrade();
        //将每题对错画成条形统计图
        PracticeReport practiceReport = practiceReportService.findOnePracticeReportByUserId(user.getId());
        //将userid为xx的学生的历史分数画成折线统计图
        List<PracticeReport> practiceReportList = practiceReportService.findAllPracticeReportByUserId(user.getId());
        Integer size=practiceReportList.size();
        //统计不同分数区间的人数，画成饼图
        Integer count1 = practiceReportService.count1();      //0-20
        Integer count2 = practiceReportService.count2();      //20-40
        Integer count3 = practiceReportService.count3();      //40-60
        Integer count4 = practiceReportService.count4();      //60-80
        Integer count5 = practiceReportService.count5();      //80-100
        Integer count6 = practiceReportService.count6(grade); //统计比该生分数低的记录
        //显示该学生超越了百分之？%的学生
        Double rank = count6 * 1.0 / ((count1 + count2 + count3 + count4 + count5) * 1.0);

        ModelAndView mv = new ModelAndView("practiceresult");

        mv.addObject("practiceReport", practiceReport);
        mv.addObject("practiceReportList", practiceReportList);
        mv.addObject("size",size);
        mv.addObject("grade", grade);
        mv.addObject("count1", count1);
        mv.addObject("count2", count2);
        mv.addObject("count3", count3);
        mv.addObject("count4", count4);
        mv.addObject("count5", count5);
        mv.addObject("count6", count6);
        mv.addObject("rank", rank);

        return mv;
    }

    @RequestMapping("practiceresult")
    public String practiceresult(){
        return "practiceresult";
    }

}


